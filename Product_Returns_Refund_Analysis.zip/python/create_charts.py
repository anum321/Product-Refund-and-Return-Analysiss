import os
import pandas as pd
import matplotlib.pyplot as plt

# Change this folder to where your cleaned CSV files are stored.
DATA_DIR = r"C:\Users\Admin\cleaned_data"
OUT_DIR = os.path.join(DATA_DIR, "charts")
os.makedirs(OUT_DIR, exist_ok=True)

orders = pd.read_csv(os.path.join(DATA_DIR, "orders_clean.csv"))
returns = pd.read_csv(os.path.join(DATA_DIR, "returns_clean.csv"))

def save_current(filename):
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, filename), dpi=300, bbox_inches="tight")
    plt.show()
    plt.close()

# 1. Return reasons
returns["return_reason"].value_counts().sort_values().plot(kind="barh", figsize=(9, 5))
plt.title("Product Returns by Reason")
plt.xlabel("Number of Returns")
plt.ylabel("Return Reason")
save_current("chart1_return_reasons.png")

# 2. Return statuses
returns["return_status"].value_counts().plot(kind="bar", figsize=(8, 5))
plt.title("Distribution of Return Status")
plt.xlabel("Return Status")
plt.ylabel("Number of Returns")
plt.xticks(rotation=30, ha="right")
save_current("chart2_return_status.png")

# 3. Monthly returns
returns["return_date"] = pd.to_datetime(returns["return_date"], errors="coerce")
monthly_returns = returns.dropna(subset=["return_date"]).set_index("return_date").resample("MS").size()
monthly_returns.plot(kind="line", marker="o", figsize=(9, 5))
plt.title("Monthly Product Return Trend")
plt.xlabel("Month")
plt.ylabel("Number of Returns")
save_current("chart3_monthly_returns.png")

# 4. Order value distribution
orders["order_total"] = pd.to_numeric(orders["order_total"], errors="coerce")
orders["order_total"].dropna().plot(kind="hist", bins=30, figsize=(8, 5))
plt.title("Distribution of Order Values")
plt.xlabel("Order Total")
plt.ylabel("Number of Orders")
save_current("chart4_order_value_distribution.png")

# 5. Monthly sales
orders["order_date"] = pd.to_datetime(orders["order_date"], errors="coerce")
monthly_sales = orders.dropna(subset=["order_date"]).set_index("order_date")["order_total"].resample("MS").sum()
monthly_sales.plot(kind="line", marker="o", figsize=(9, 5))
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Total Sales")
save_current("chart5_monthly_sales.png")

# 6. Payment method distribution
orders["payment_method"].value_counts().plot(kind="bar", figsize=(8, 5))
plt.title("Orders by Payment Method")
plt.xlabel("Payment Method")
plt.ylabel("Number of Orders")
plt.xticks(rotation=30, ha="right")
save_current("chart6_payment_methods.png")

print(f"Charts saved to: {OUT_DIR}")
