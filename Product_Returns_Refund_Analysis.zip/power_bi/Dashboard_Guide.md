# Power BI Dashboard Guide

## Before starting
Use Power BI Desktop. Import the four cleaned CSV files from your local `cleaned_data` folder. Confirm field names and data types after import.

## Suggested model
- `orders[customer_id]` → `customers[customer_id]`
- `orders[product_id]` → `products[product_id]`
- `orders[order_id]` → `returns[order_id]`

Use single-direction filtering where possible. Confirm actual relationship cardinality and ensure IDs match. If Power BI reports ambiguous relationships, pause and review the model rather than forcing many-to-many relationships.

## Page 1: Executive Overview
- KPI card: Total Orders
- KPI card: Total Returns
- KPI card: Return-to-Order Ratio
- Bar chart: Return Count by Return Reason
- Donut or bar chart: Return Count by Return Status
- Line chart: Monthly Returns
- Slicers: Return Date, Return Reason, Return Status

## Page 2: Return Details
- Stacked column chart: Return Reason by Return Status
- Bar chart: Product or category by return count (if product/category columns are available)
- Table: Return ID, Order ID, Return Date, Return Reason, Return Status
- Slicers: date, reason, status, category if available

## Starter DAX measures
```DAX
Total Orders = DISTINCTCOUNT(orders[order_id])

Total Returns = DISTINCTCOUNT(returns[return_id])

Return-to-Order Ratio % =
DIVIDE([Total Returns], [Total Orders], 0)

Pending Refund Returns =
CALCULATE(
    [Total Returns],
    returns[return_status] = "Approved - Pending Refund"
)
```
Format `Return-to-Order Ratio %` as Percentage. Note: this is a simple ratio of distinct returns to distinct orders, not necessarily a cohort-based return rate.

## Important refund warning
Do not create Total Refund or Average Refund cards yet. The imported MySQL returns table was showing all refund amounts as 0.00, while Python/source CSV inspection showed positive values. Validate the refund column and refresh Power BI only after the mismatch is corrected.

## Finish and export
1. Add a clear title and consistent labels.
2. Test every slicer and chart interaction.
3. Save as `Product_Returns_Refund_Analysis.pbix`.
4. Take screenshots of each dashboard page and save them in the repository under `power_bi/screenshots/`.
5. Do not claim the `.pbix` is complete until you have built and saved it in Power BI Desktop.
