-- Product Returns & Refund Analysis
USE product_returns_analysis;

-- 1. Table counts
SELECT 'orders' AS table_name, COUNT(*) AS total_rows FROM orders
UNION ALL
SELECT 'returns', COUNT(*) FROM returns
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'customers', COUNT(*) FROM customers;

-- 2. Return-to-order ratio (simple count ratio)
SELECT
    (SELECT COUNT(*) FROM orders) AS total_orders,
    (SELECT COUNT(*) FROM returns) AS total_returns,
    ROUND((SELECT COUNT(*) FROM returns) * 100.0 /
          NULLIF((SELECT COUNT(*) FROM orders), 0), 2) AS return_to_order_ratio_pct;

-- 3. Return reasons
SELECT return_reason, COUNT(*) AS return_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM returns), 2) AS percentage
FROM returns
GROUP BY return_reason
ORDER BY return_count DESC;

-- 4. Return statuses
SELECT return_status, COUNT(*) AS return_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM returns), 2) AS percentage
FROM returns
GROUP BY return_status
ORDER BY return_count DESC;

-- 5. Monthly returns
SELECT DATE_FORMAT(return_date, '%Y-%m') AS return_month,
       COUNT(*) AS return_count
FROM returns
GROUP BY DATE_FORMAT(return_date, '%Y-%m')
ORDER BY return_month;

-- 6. Returns by product/order (adjust joins if your schema differs)
SELECT o.product_id, COUNT(*) AS return_count
FROM returns r
JOIN orders o ON r.order_id = o.order_id
GROUP BY o.product_id
ORDER BY return_count DESC
LIMIT 10;

-- 7. Refund data validation: do not use refund totals until import discrepancy is fixed
SELECT COUNT(*) AS total_records,
       SUM(refund_amount > 0) AS positive_refunds,
       MIN(refund_amount) AS minimum_refund,
       MAX(refund_amount) AS maximum_refund,
       ROUND(SUM(refund_amount), 2) AS total_refund
FROM returns;

-- 8. Pending refund follow-up
SELECT return_status, COUNT(*) AS records
FROM returns
WHERE return_status = 'Approved - Pending Refund'
GROUP BY return_status;
