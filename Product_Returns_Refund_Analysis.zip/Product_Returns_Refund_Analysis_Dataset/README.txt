Product Returns & Refund Analysis — Synthetic Dataset

This is a synthetic, project-ready e-commerce dataset. It does not contain real customer data.

Files and row counts:
- orders.csv: 15,000 order records
- returns.csv: 3,200 return/refund records
- products.csv: 1,200 product records
- customers.csv: 4,000 customer records
Total: 23,400 rows across the four tables.

Relationships:
- orders.customer_id -> customers.customer_id
- orders.product_id -> products.product_id
- returns.order_id -> orders.order_id

Suggested analysis:
- Return rate by product category and brand
- Refund amount and refund status analysis
- Return reasons by product category
- Customer segments with the highest return rate
- Average days between order and return
- Revenue before/after refunds
- Return rates by payment method, city/state, and month

All data is synthetic and intended for learning, SQL, Excel, and Power BI portfolio projects.
Returns are linked to delivered orders; refund amount is zero for rejected and exchange-issued cases.
